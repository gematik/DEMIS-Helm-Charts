{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "routing.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "routing.labels" -}}
{{ include "routing.selectorLabels" . }}
{{ if .Chart.AppVersion -}}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
helm.sh/chart: {{ include "routing.chart" . | quote }}
{{- with .Values.customLabels }}
{{- toYaml . }}
{{- end }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "routing.selectorLabels" -}}
app: {{ include "routing.application.name" . | quote }}
app.kubernetes.io/app: {{ include "routing.application.name" . | quote }}
{{- end -}}

{{/*
Application Name
*/}}
{{- define "routing.application.name" -}}
{{ required "An Application Name is required!" .Values.appName | trunc 63 }}
{{- end -}}

{{/*
Application Namespace
*/}}
{{- define "routing.application.namespace" -}}
{{ .Values.appNamespace | default .Release.Namespace | trunc 63 }}
{{- end }}

{{/*
Application Internal Host Address
*/}}
{{- define "routing.application.host" -}}
{{- printf "%s.%s.svc.cluster.local" (include "routing.application.name" .) (include "routing.application.namespace" .) }}
{{- end -}}

{{/*
Define Destinatio Subsets as building block
*/}}
{{- define "routing.service.destination.subsets" -}}
{{- $port := .Values.appServicePortExternal -}}
{{- $host := include "routing.application.host" . -}}
{{- if .Values.destinationSubsets -}}
route:
  {{- range $k, $v := .Values.destinationSubsets }}
  - destination:
      host: {{ printf "%s" $host }}
      subset: {{ regexReplaceAll "\\.+" ( default $v.version $v.name ) "-" }}
      port:
        number: {{ $port }}
    weight: {{ $v.weight }}
    {{- if hasKey $v "mirror" }}
    mirror:
      host: {{ printf "%s" $host }}
      subset: {{ regexReplaceAll "\\.+" ( default $v.mirror.version $v.name ) "-" }}
      mirrorPercentage:
        value: {{ $v.mirror.mirrorPercentage }}
    {{- end }}
  {{- end }}
{{- end -}}
{{- end -}}

{{/*}}
Define Default Virtual Service HTTP Rules
The Routes block goes under the http rule entry block (at same level of match/timeout/etc.) 
*/}}
{{- define "routing.service.default.http.rules" -}}
{{- $routes := include "routing.service.destination.subsets" . | fromYaml -}}
{{- $rules := list }}
{{- range $rule := .Values.virtualServiceHttpRules }}
{{- $rules = append $rules (merge (deepCopy $routes) $rule) }}
{{- end }}
{{ toYaml $rules }}
{{- end -}}

{{/*}}
Define Default Virtual Service TCP Rules
The Routes block goes under the http rule entry block (at same level of match/timeout/etc.) 
*/}}
{{- define "routing.service.default.tcp.rules" -}}
{{- $routes := include "routing.service.destination.subsets" . -}}
{{- range $rules := .Values.virtualServiceTcpRules }}
- {{- toYaml $rules | nindent 2 }}
{{- print $routes | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
Detect if the external routing is defined
The Routes block goes under the http rule entry block (at same level of match/timeout/etc.) 
*/}}
{{- define "routing.service.external.http.rules" -}}
{{- $routes := include "routing.service.destination.subsets" . | fromYaml -}}
{{- if and (.Values.virtualServiceExternalHttpRules) (gt (len .Values.virtualServiceExternalHttpRules) 0) -}}
{{- $rules := list }}
{{- range $rule := .Values.virtualServiceExternalHttpRules }}
{{- $rules = append $rules (merge (deepCopy $routes) $rule) }}
{{- end }}
{{ toYaml $rules }}
{{- else -}}
{{- include "routing.service.default.http.rules" . -}}
{{- end -}}
{{- end -}}

{{/*
Build http rule from custom object. will also parse string to http object.
*/}}
{{- define "routing.service.custom.http.rules" }}
{{- if kindIs "string" .Values.CustomVirtualServiceHttpRules }}
{{ tpl .Values.CustomVirtualServiceHttpRules . }}
{{- else }}
{{ .Values.CustomVirtualServiceHttpRules | toYaml }}
{{- end }}
{{- end }}

{{/*
Build http rule from custom object. will also parse string to http object.
*/}}
{{- define "routing.service.custom.external.http.rules" }}
{{- $rules := (.Values.CustomVirtualServiceExternalHttpRules | default .Values.CustomVirtualServiceHttpRules) }}
{{- if kindIs "string" $rules }}
{{ tpl $rules . }}
{{- else }}
{{ $rules | toYaml }}
{{- end }}
{{- end }}

{{/*
Build destination subset from custom object. will also parse string to destination subset object.
*/}}
{{- define "routing.service.custom.destination.subsets" }}
{{- if kindIs "string" .Values.CustomDestinationSubsets }}
{{ tpl .Values.CustomDestinationSubsets . }}
{{- else }}
{{ .Values.CustomDestinationSubsets | toYaml }}
{{- end }}
{{- end -}}
