{{/*
Expand the name of the chart.
*/}}
{{- define "redis.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "redis.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "redis.fullversionname" -}}
{{- if .Values.istio.enable }}
{{- $name := include "redis.fullname" . }}
{{- $version := regexReplaceAll "\\.+" .Chart.Version "-" }}
{{- printf "%s-%s" $name $version | trunc 63 }}
{{- else }}
{{- include "redis.fullname" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "redis.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "redis.labels" -}}
helm.sh/chart: {{ include "redis.chart" . }}
{{ include "redis.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.customLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "redis.selectorLabels" -}}
{{ if .Values.istio.enable -}}
app: {{ include "redis.name" . }}
version: {{ .Chart.AppVersion | quote }}
{{ end -}}
app.kubernetes.io/name: {{ include "redis.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "redis.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "redis.fullversionname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get ConfigMap name from values
*/}}
{{- define "redis.configMapName" -}}
{{- print (include "redis.fullversionname" .) }}
{{- end }}

{{/*
Get Persistence Volume Claim name from values
*/}}
{{- define "redis.pvcName" -}}
{{- if not .Values.config.persistence.volumeClaim.useDefault }}
{{- print (.Values.config.persistence.volumeClaim.name | required ".Values.config.persistence.volumeClaim.name is required.") }}
{{- else }}
{{- print "pvc-" (include "redis.fullversionname" .) }}
{{- end }}
{{- end }}

{{/*
Get Secret name from values
*/}}
{{- define "redis.authSecretName" -}}
{{- if not .Values.config.auth.useDefault }}
{{- print (.Values.config.auth.secret.name | required ".Values.config.auth.secret.name is required.") }}
{{- else }}
{{- print "secret-" (include "redis.fullversionname" .) }}
{{- end }}
{{- end }}

{{/*
Get Auth Secret key from Values
*/}}
{{- define "redis.authSecretKey" -}}
{{- if not .Values.config.auth.useDefault }}
{{- print (.Values.config.auth.secret.key | required ".Values.config.auth.secret.key is required.") }}
{{- else }}
{{- print "users.acl" }}
{{- end }}
{{- end }}
