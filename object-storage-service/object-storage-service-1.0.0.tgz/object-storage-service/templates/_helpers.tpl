{{/*
Expand the name of the chart.
*/}}
{{- define "object-storage-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "object-storage-service.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "object-storage-service.fullversionname" -}}
{{- if .Values.istio.enable }}
{{- $name := include "object-storage-service.fullname" . }}
{{- $version := regexReplaceAll "\\.+" .Chart.Version "-" }}
{{- printf "%s-%s" $name $version | trunc 63 }}
{{- else }}
{{- include "object-storage-service.fullname" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "object-storage-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "object-storage-service.labels" -}}
helm.sh/chart: {{ include "object-storage-service.chart" . }}
{{ include "object-storage-service.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.customLabels }}
{{ toYaml . | nindent 8 }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "object-storage-service.selectorLabels" -}}
{{ if .Values.istio.enable -}}
app: {{ include "object-storage-service.name" . }}
version: {{ .Chart.AppVersion | quote }}
{{ end -}}
app.kubernetes.io/name: {{ include "object-storage-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "object-storage-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "object-storage-service.fullversionname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Get ConfigMap name from values
*/}}
{{- define "object-storage-service.configMapName" -}}
{{- if not .Values.config.useDefault }}
{{- print (.Values.config.settings.configMap.name | required ".Values.config.settings.configMap.name is required.") }}
{{- else }}
{{- print "config-" (include "object-storage-service.fullversionname" .) }}
{{- end }}
{{- end }}

{{/*
Get Persistence Volume Claim name from values
*/}}
{{- define "object-storage-service.pvcName" -}}
{{- if not .Values.config.persistence.volumeClaim.useDefault }}
{{- print (.Values.config.persistence.volumeClaim.name | required ".Values.config.persistence.volumeClaim.name is required.") }}
{{- else }}
{{- print "pvc-" (include "object-storage-service.fullversionname" .) }}
{{- end }}
{{- end }}

{{/*
Get Persistence Volume name from values
*/}}
{{- define "object-storage-service.pvName" -}}
{{- print "pv-" (include "object-storage-service.fullversionname" .) }}
{{- end }}

{{/*
Get S3 Secret name from values
*/}}
{{- define "object-storage-service.s3SecretName" -}}
{{- if and (not .Values.config.secrets.s3.name) (not .Values.config.secrets.useDefault) }}
{{- fail ".Values.config.secrets.s3.name is required" }}
{{- else }}
{{- if .Values.config.secrets.useDefault }}
{{- print "secret-" (include "object-storage-service.fullversionname" .) }}
{{- else }}
{{- print .Values.config.secrets.s3.name }}
{{- end }}
{{- end }}
{{- end }}