{{/*
Expand the name of the chart.
*/}}
{{- define "notification-clearing-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "notification-clearing-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "notification-clearing-api.fullversionname" -}}
{{- if .Values.istio.enable }}
{{- $name := include "notification-clearing-api.fullname" . }}
{{- $version := regexReplaceAll "\\.+" .Chart.Version "-" }}
{{- printf "%s-%s" $name $version | trunc 63 }}
{{- else }}
{{- include "notification-clearing-api.fullname" . }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "notification-clearing-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "notification-clearing-api.labels" -}}
helm.sh/chart: {{ include "notification-clearing-api.chart" . }}
{{ include "notification-clearing-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.customLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "notification-clearing-api.selectorLabels" -}}
{{ if .Values.istio.enable -}}
app: {{ include "notification-clearing-api.name" . }}
version: {{ .Chart.AppVersion | quote }}
{{ end -}}
app.kubernetes.io/name: {{ include "notification-clearing-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Deployment labels
*/}}
{{- define "notification-clearing-api.deploymentLabels" -}}
{{ if .Values.istio.enable -}}
istio-validate-jwt: "{{ .Values.istio.validateJwt | required ".Values.istio.validateJwt is required" }}"
{{- with .Values.deploymentLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "notification-clearing-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "notification-clearing-api.fullversionname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Get ConfigMap name from values
*/}}
{{- define "notification-clearing-api.configMapName" -}}
{{- if not .Values.config.configMap.useDefault }}
{{- print (.Values.config.configMap.name | required ".Values.config.configMap.name is required.") }}
{{- else }}
{{- print "config-" (include "notification-clearing-api.fullversionname" .) }}
{{- end }}
{{- end }}

{{/*
Get Default Secret name 
*/}}
{{- define "notification-clearing-api.defaultSecretName" -}}
{{- print "secret-" (include "notification-clearing-api.fullversionname" .) }}
{{- end }}

{{/*
Get API Keys Secret name from Values
*/}}
{{- define "notification-clearing-api.apiKeySecretName" -}}
{{- if and (not .Values.config.secret.api.name) (not .Values.config.secret.useDefault) }}
{{- fail ".Values.config.secret.api.name is required" }}
{{- end }}
{{- print .Values.config.secret.api.name }}
{{- end }}

{{/*
Get API Keys Secret name from Values
*/}}
{{- define "notification-clearing-api.dbSecretName" -}}
{{- if and (not .Values.config.secret.db.name) (not .Values.config.secret.useDefault) }}
{{- fail ".Values.config.secret.db.name is required" }}
{{- end }}
{{- print .Values.config.secret.db.name }}
{{- end }}

{{/*
Get CA Certificates Secret name from Values
*/}}
{{- define "notification-clearing-api.caCertificatesSecretName" -}}
{{- if and (not .Values.config.secret.cacerts.name) (not .Values.config.secret.useDefault) }}
{{- fail ".Values.config.secret.cacerts.name is required" }}
{{- end }}
{{- print .Values.config.secret.cacerts.name }}
{{- end }}
